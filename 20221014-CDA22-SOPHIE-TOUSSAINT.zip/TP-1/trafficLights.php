<?php

// interface SplSubject
// {

//     public function attach(SplObserver $observer);
//     public function detach(SplObserver $observer);
//     public function notifyDriver();
// }

// interface SplObserver
// {

//     public function sendInfo();
// }

class traficLights
{

    private $colorRed = "Red";
    private $colorOrange = "Orange";
    private $colorGreen = "Green";
    private $color;


    public function getColorRed()
    {
        return $this->colorRed;
    }
    public function setColorRed($colorRed)
    {
        $this->colorRed = $colorRed;
    }


    public function getColorOrange()
    {
        return $this->colorOrange;
    }
    public function setColorOrange($colorOrange)
    {
        $this->colorOrange = $colorOrange;
    }


    public function getColorGreen()
    {
        return $this->colorGreen;
    }
    public function setColorGreen($colorGreen)
    {
        $this->colorGreen = $colorGreen;
    }


    public function getColor()
    {
        return $this->color;
    }
    public function setColor($color)
    {
        $this->color = $color;
    }

    public function changeLightColors($color)
    {
        $color = array(
            "Green" => '1',
            "Orange" => '2',
            "Red" => '3'
        );
        $this->color = array_rand($color);

        echo "<p>Trafic light color has just changed to {$this->color}</p>";
    }
}


class Driver
{

    public function drive($color)
    {
        $color = array(
            "Green" => '1',
            "Orange" => '2',
            "Red" => '3'
        );
        if ($this->color == "Green") {
            echo "You can pass";
        } else if ($this->color == "Orange") {
            echo "You have to slow down";
        } else if ($this->color  == "Red") {
            echo "You have to stop";
        }
    }
}



$trafic = new traficLights();
$driver = new Driver();
if ($trafic->changeLightColors('Green')) {
    $driver->drive("Green");
} else if ($trafic->changeLightColors('Orange')) {
    $driver->drive("Orange");
} else if ($trafic->changeLightColors('Red')) {
    $driver->drive("Red");
}
